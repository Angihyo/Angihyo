import numpy as np  
import cv2  
  
capture = cv2.VideoCapture('Video Traffic Light Sequence.mp4')
bluemin = [110,50,50]
bluemax = [130,255,255]

redmin1 = [0, 50, 50]
redmax1 = [10, 255, 255]
redmin2 = [160,50,50]
redmax2 = [179,255,255]

greenmin = [70,50,50]
greenmax = [90,255,255]

yellowmin = [10,50,50]
yellowmax = [30,255,255]

def setcolor(a,b):
    # define range of blue color in HSV  
    lower_blue = np.array(a)  
    upper_blue = np.array(b)  
  
    # Threshold the HSV image to get only blue colors  
    mask = cv2.inRange(img_hsv, lower_blue, upper_blue)  
  
    # Bitwise-AND mask and original image  
    img_result = cv2.bitwise_and(frame,frame, mask= mask)  
  
  
    cv2.imshow( 'mask', mask )  
    cv2.imshow( 'img_result', img_result )  
    
  
while(1):  
    ret,frame = capture.read()  
  
    img_hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)  
  
    cv2.imshow( 'webcam', frame )  
  
    img_h, img_s, img_v = cv2.split(img_hsv)  
    cv2.imshow( 'h', img_h )  
    cv2.imshow( 's', img_s )  
    cv2.imshow( 'v', img_v )  
  
    setcolor(greenmin, greenmax)
  
    if cv2.waitKey(30)&0xFF == ord('q'):  
        break;  
  
  
capture.release()  
cv2.destroyAllWindows()  
